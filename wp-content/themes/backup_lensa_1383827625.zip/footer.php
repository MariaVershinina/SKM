  
</div>

<!-- Progress bar for supersized -->
<div class="progress-wrapper">
  <div class="progress-bar"></div>
</div>

<footer class="footer-section container">
  <div class="row">
    <?/*php colabs_social_net("social-links")*/?>
  
</footer><!-- .footer-section -->

<?php wp_footer(); ?>
</body>
</html>
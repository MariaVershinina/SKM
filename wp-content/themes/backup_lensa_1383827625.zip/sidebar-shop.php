<div class="primary-sidebar shop-sidebar column col4">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar-shop') ) :  ?>
	
	<?php endif; ?>
</div><!-- .primary-sidebar -->
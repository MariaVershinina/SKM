<?php
	class PowerHour_Geocoder_UnknownAddressException extends PowerHour_Geocoder_Exception
	{
		
	}
<?php get_header(); ?>
 

<div class="row">
    <div class="slide-info-wrapper col8">
      <div class ="skm">
       
         <b>а    н    с    а    м    б    л    ь</b><br>
        <b>С    Т    А    Р    И    Н    Н    О    Й</b><br>
        <b>К    Р    Е    С    Т    Ь    Я    Н    С    К    О    Й</b><br>
        <b>М    У    З    Ы    К    И</b><br>
  </div>

  
    
    </div><!-- .slide-info-wraper -->
  </div>


<?php get_footer(); ?>
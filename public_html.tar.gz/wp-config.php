<?php
/**
 * Основные параметры WordPress.
 *
 * Этот файл содержит следующие параметры: настройки MySQL, префикс таблиц,
 * секретные ключи, язык WordPress и ABSPATH. Дополнительную информацию можно найти
 * на странице {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Кодекса. Настройки MySQL можно узнать у хостинг-провайдера.
 *
 * Этот файл используется сценарием создания wp-config.php в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать этот файл
 * с именем "wp-config.php" и заполнить значения.
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'u231577831_skm');

/** Имя пользователя MySQL */
define('DB_USER', 'u231577831_skm');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'skm14/88');

/** Имя сервера MySQL */
define('DB_HOST', 'mysql.hostinger.ru');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется снова авторизоваться.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'ax@+_|T-3@Vlrwl7OEbkSVRZHoNR$,AacD:BWu,l^fr[6UM|P*eS-=6|R3[L(&PC');
define('SECURE_AUTH_KEY',  'rxxM7Y+vBxWLZhkJ%2_plH+!B7*=36|w8W=&!}*SqeYd2~xFk*F>)+heeA|9ej$+');
define('LOGGED_IN_KEY',    '>#t7H-R9>Y9[*aT:pkO$VD;:D0W+_1Iv]|`UO09~H6-dAg|yv~9$AHt/a-=a<n^k');
define('NONCE_KEY',        'YXXp-EJDFdZkl*OE +S AQ9Kn`pZK=ViY|f&c<xLP;+UP-w3O:Jw@i1-|rBVK*K1');
define('AUTH_SALT',        'Ap!h{-l.>e<^a&iL6 {Vdi9X0%l9~>1nAd-$IicCpNUdq q6z<V@p%v_;sEMc}p9');
define('SECURE_AUTH_SALT', '[LNI-bH97o>pv9P$+A)!QOLw&<VO#n0%|:5IB}|5rrCCpOg{2SE/YYL,iP&VM5ca');
define('LOGGED_IN_SALT',   'g.xn1=$$TJ6Sfc]{,T`_*Z[,+57p3b9#d-;3H;7J8.,?z<Z_EjVPM/S.ehonXqX8');
define('NONCE_SALT',       '9k]lJ@ rY^!P}};,{^[O+Ax}HMR*w$gWTl|2P=Kgo(zmh$x.yM]N:JQaKu;(+,p%');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько блогов в одну базу данных, если вы будете использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Язык локализации WordPress, по умолчанию английский.
 *
 * Измените этот параметр, чтобы настроить локализацию. Соответствующий MO-файл
 * для выбранного языка должен быть установлен в wp-content/languages. Например,
 * чтобы включить поддержку русского языка, скопируйте ru_RU.mo в wp-content/languages
 * и присвойте WPLANG значение 'ru_RU'.
 */
define('WPLANG', 'ru_RU');

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Настоятельно рекомендуется, чтобы разработчики плагинов и тем использовали WP_DEBUG
 * в своём рабочем окружении.
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
